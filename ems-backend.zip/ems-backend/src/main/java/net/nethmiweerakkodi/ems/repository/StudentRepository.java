package net.nethmiweerakkodi.ems.repository;

import net.nethmiweerakkodi.ems.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository  extends JpaRepository<Student,Long> {
}

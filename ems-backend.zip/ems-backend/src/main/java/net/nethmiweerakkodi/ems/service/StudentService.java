package net.nethmiweerakkodi.ems.service;

import net.nethmiweerakkodi.ems.dto.StudentDto;
import net.nethmiweerakkodi.ems.entity.Student;

import java.util.List;

public interface StudentService {
    StudentDto createStudent(StudentDto studentDto);

    StudentDto getStudentById(Long studentId);

    List<StudentDto> getAllStudents();

    StudentDto updateStudent(Long studentId, StudentDto updatedStudent);

    void deleteStudent(Long studentId);
}

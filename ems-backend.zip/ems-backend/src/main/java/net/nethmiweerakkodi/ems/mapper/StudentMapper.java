package net.nethmiweerakkodi.ems.mapper;

import net.nethmiweerakkodi.ems.dto.StudentDto;
import net.nethmiweerakkodi.ems.entity.Student;


public class StudentMapper {

    public static StudentDto mapToStudentDto(Student student){
        return new StudentDto(
                student.getId(),
                student.getFirstName(),
                student.getLastName(),
                student.getEmail(),
                student.getNumber(),
                student.getProgramme(),
                student.getFees()

        );
    }

    public static Student mapToStudent(StudentDto studentDto){
        return new Student(
                studentDto.getId(),
                studentDto.getFirstName(),
                studentDto.getLastName(),
                studentDto.getEmail(),
                studentDto.getNumber(),
                studentDto.getProgramme(),
                studentDto.getFees()
        );
    }
}